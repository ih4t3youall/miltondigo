package com.leaderboard;

public class Score {

	private String name = "Milton";

	private Long score = 1L;

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getScore() {
		return score;
	}

	public void setScore(Long score) {
		this.score = score;
	}

}
